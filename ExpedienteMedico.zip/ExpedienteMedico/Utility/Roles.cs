﻿namespace ExpedienteMedico.Utility
{
    public class Roles
    {
        public const string Role_Admin = "admin";
        public const string Role_Physician = "physician";
        public const string Role_Patient = "patient";

    }
}
